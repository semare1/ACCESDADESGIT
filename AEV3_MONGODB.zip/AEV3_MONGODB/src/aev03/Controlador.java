package aev03;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import org.json.simple.parser.ParseException;

public class Controlador {

	protected static final Component JFrame = null;

	private Vista vista;
	private Modelo modelo;
	private ActionListener actionListener_acces, actionListener_crear, actionListener_eliminar, actionListener_editar,
			actionListener_visualitzaSegunId, actionListener_eliminarColeccion, actionListener_tamanyoColeccion,
			actionListener_visualitzaDatos, actionListener_consultaIgual, actionListener_consultaMayor,
			actionListener_consultaMenor, actionListener_tancarCon;
	// private ActionListener ;

	public Controlador(Vista vista, Modelo modelo) {
		this.vista = vista;
		this.modelo = modelo;

		control();
	}

	/**
	 * 
	 */
	public void control() {

		vista.getPanel_funciones().setVisible(false);

		actionListener_acces = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String usr = vista.getTextField().getText();
				String passwd = vista.getPasswordField().getText();
				if (modelo.userAutoritzat(usr, passwd)) {
					JOptionPane.showMessageDialog(JFrame, "L'usuari " + usr + " a iniciat sessió");
					vista.getPanel_funciones().setVisible(true);
					vista.getPanel_login().setVisible(false);
					vista.getTextField().setText("");
					vista.getPasswordField().setText("");
				} else {
					JOptionPane.showMessageDialog(JFrame, "Usuari no autoritzat");
					vista.getTextField().setText("");
					vista.getPasswordField().setText("");
				}

			}

		};
		vista.getBtnAcces().addActionListener(actionListener_acces);

		actionListener_crear = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				modelo.afexirLlibre();

			}

		};
		vista.getBtnCrear().addActionListener(actionListener_crear);

		actionListener_eliminar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				modelo.eliminarLlibre();

			}

		};
		vista.getBtnBorrar().addActionListener(actionListener_eliminar);

		actionListener_editar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				modelo.editarLlibre();

			}

		};
		vista.getBtnActualitza().addActionListener(actionListener_editar);

		actionListener_visualitzaSegunId = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String dadesVisualitzar = "";
				try {
					dadesVisualitzar = modelo.consultarLlibre();
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				vista.getTextAreaVisor().setText(dadesVisualitzar);

			}

		};
		vista.getBtnMostrar().addActionListener(actionListener_visualitzaSegunId);

		actionListener_eliminarColeccion = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				modelo.eliminarColeccio();
			}

		};
		vista.getBtnEliminaColeccio().addActionListener(actionListener_eliminarColeccion);

		actionListener_tamanyoColeccion = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String dadesVisualitzar = "";
				dadesVisualitzar = modelo.totalElements();
				vista.getTextAreaVisor().setText(dadesVisualitzar);

			}

		};
		vista.getBtnNomElements().addActionListener(actionListener_tamanyoColeccion);
		
		actionListener_visualitzaDatos = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String dadesVisualitzar = "";
				try {
					dadesVisualitzar = modelo.visualitzaInfo();
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				vista.getTextAreaVisor().setText(dadesVisualitzar);
				
			}
			
		};
		vista.getBtnVeureLlibres().addActionListener(actionListener_visualitzaDatos);
		
		actionListener_consultaIgual = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					vista.getTextAreaVisor().setText(modelo.consultaIgual());
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
			
		};
		vista.getBtnIgual().addActionListener(actionListener_consultaIgual);
		
		 actionListener_consultaMayor = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					vista.getTextAreaVisor().setText(modelo.consultaMayorQue());
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			 
		 };
		 vista.getBtnMajor().addActionListener(actionListener_consultaMayor);
		 
		 actionListener_consultaMenor = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					vista.getTextAreaVisor().setText(modelo.consultaMenorQue());
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			 
		 };
		 vista.getBtnMenor().addActionListener(actionListener_consultaMenor);
		 
		 actionListener_tancarCon = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int respuesta = JOptionPane.showConfirmDialog(JFrame, "¿Estes segur de que vols tancar sessió?");
				if (respuesta == JOptionPane.YES_OPTION) {
					vista.getPanel_funciones().setVisible(false);
					vista.getPanel_login().setVisible(true);
					
				}
				
			}
			 
		 };
		 vista.getBtnTancarConexio().addActionListener(actionListener_tancarCon);
	}

}
