package aev03;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.gte;
import static com.mongodb.client.model.Filters.lte;
import static com.mongodb.client.model.Filters.and;

import java.io.FileReader;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.bson.Document;
import org.bson.conversions.Bson;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

/**
 * @author Ariadna Redondo
 * @author Sergio Matarredona
 */
public class Modelo {

	String ip, port, bd, llibres, users;
	
	/**
	 * Constructor donde guardamos la información del 
	 * archivo json en las variables locales; ip,port,bd,llibres y users
	 */

	Modelo() {
		JSONParser jsonParser = new JSONParser();

		try {
			FileReader reader = new FileReader("./src/aev03/conexio.json");
			Object obj = jsonParser.parse(reader);

			JSONObject jo = (JSONObject) obj;

			this.ip = (String) jo.get("ip");
			this.port = (String) jo.get("port");
			this.bd = (String) jo.get("bd");
			this.llibres = (String) jo.get("llibres");
			this.users = (String) jo.get("users");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * 
	 * @param recibe la contraseña introducida por el usuario.
	 * @return devuelve la contraseña parseada.
	 */

	public String parsearContra(final String base) {
		try {
			final MessageDigest digest = MessageDigest.getInstance("SHA-256");
			final byte[] hash = digest.digest(base.getBytes("UTF-8"));
			final StringBuilder hexString = new StringBuilder();
			for (int i = 0; i < hash.length; i++) {
				final String hex = Integer.toHexString(0xff & hash[i]);
				if (hex.length() == 1)
					hexString.append('0');
				hexString.append(hex);
			}
			return hexString.toString();
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * 
	 * @param nomUser
	 * @param contra
	 * @return devuelve true en caso de que el usuario esté autorizado
	 */
	public boolean userAutoritzat(String nomUser, String contra) {

		boolean valido = false;
		String pass = parsearContra(contra);

		MongoClient mongoClient = new MongoClient(this.ip, Integer.parseInt(this.port));
		MongoDatabase database = mongoClient.getDatabase(this.bd);
		MongoCollection<Document> coleccion = database.getCollection(this.users);
		MongoCursor<Document> cursor = coleccion.find().iterator();

		Bson query = and(Arrays.asList(eq("user", nomUser), eq("pass", pass)));
		cursor = coleccion.find(query).iterator();

		if (cursor.hasNext()) {

			valido = true;
		} else {
			valido = false;
		}

		mongoClient.close();
		return valido;
	}

	/**
	 * Añade un nuevo libro a la base de datos de books
	 */
	
	public void afexirLlibre() {

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		JTextField id = new JTextField();
		JTextField titulo = new JTextField();
		JTextField autor = new JTextField();
		JTextField anyo_nacimiento = new JTextField();
		JTextField anyo_publicacion = new JTextField();
		JTextField editorial = new JTextField();
		JTextField numero_paginas = new JTextField();
		JTextField thumbnail = new JTextField();

		Object[] datos = { "Id: ", id, "Titol: ", titulo, "Autor: ", autor, "Any de Naixement", anyo_nacimiento,
				"Any de publicació: ", anyo_publicacion, "Editorial: ", editorial, "Nombre de págines: ",
				numero_paginas, "Thumbnail: ", thumbnail };

		int opcio = JOptionPane.showConfirmDialog(null, datos, "Afexir un llibre a la biblioteca",
				JOptionPane.YES_NO_OPTION);

		if (opcio == JOptionPane.YES_OPTION) {

			System.out.println(id.getText() + titulo.getText() + autor.getText() + anyo_nacimiento.getText()
					+ anyo_publicacion.getText() + editorial.getText() + numero_paginas.getText()
					+ thumbnail.getText());

			Document doc = new Document();
			doc.append("Id", Integer.parseInt(id.getText()));
			doc.append("Titulo", titulo.getText());
			doc.append("Autor", autor.getText());
			doc.append("Anyo_nacimientot", Integer.parseInt(anyo_nacimiento.getText()));
			doc.append("Anyo_publicacion", Integer.parseInt(anyo_publicacion.getText()));
			doc.append("Editorial", editorial.getText());
			doc.append("Numero_paginas", Integer.parseInt(numero_paginas.getText()));
			doc.append("Thumbnail", thumbnail.getText());

			coleccion.insertOne(doc);
			System.out.println("Nuevo libro anyadido con exito!");
			JOptionPane.showMessageDialog(null, "Nou llibre afegit amb exit");

		} else {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}

		mongoClient.close();
	}
	
	/**
	 * Elimina el libro de la base de datos books según su id
	 */

	public void eliminarLlibre() {

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		JTextField id = new JTextField();

		Object[] datos = { "Introduixca l'id del llibre que vol esborrar: ", id };

		int opcio = JOptionPane.showConfirmDialog(null, datos, "Esborrar llibre", JOptionPane.YES_NO_OPTION);

		if (opcio == JOptionPane.YES_OPTION) {
			coleccion.deleteOne(eq("Id", Integer.parseInt(id.getText())));

			JOptionPane.showMessageDialog(null,
					"Llibre amb id " + Integer.parseInt(id.getText()) + " eliminat amb exit!");
			System.out.println("Llibre amb id " + Integer.parseInt(id.getText()) + " eliminat amb exit!");
		} else {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}
		mongoClient.close();
	}
	
	/**
	 * Edita un el libro seleccionado según el id
	 */

	public void editarLlibre() {

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		JTextField id = new JTextField();

		Object[] datos = { "Introduixca l'id del llibre que vol editar: ", id };

		int opcio1 = JOptionPane.showConfirmDialog(null, datos, "Editar llibre", JOptionPane.YES_NO_OPTION);

		if (opcio1 == JOptionPane.YES_OPTION) {

			JTextField idNou = new JTextField();
			JTextField titulo = new JTextField();
			JTextField autor = new JTextField();
			JTextField anyo_nacimiento = new JTextField();
			JTextField anyo_publicacion = new JTextField();
			JTextField editorial = new JTextField();
			JTextField numero_paginas = new JTextField();
			JTextField thumbnail = new JTextField();

			Object[] datosNuevos = { "Id: ", idNou, "Titol: ", titulo, "Autor: ", autor, "Any de Naixement",
					anyo_nacimiento, "Any de publicació: ", anyo_publicacion, "Editorial: ", editorial,
					"Nombre de págines: ", numero_paginas, "Thumbnail: ", thumbnail };

			int opcio2 = JOptionPane.showConfirmDialog(null, datosNuevos, "Afexir un llibre a la biblioteca",
					JOptionPane.YES_NO_OPTION);

			if (opcio2 == JOptionPane.YES_OPTION) {
				System.out.println("Actualizando informacion...");

				Document doc = new Document();
				doc.append("Id", Integer.parseInt(idNou.getText()));
				doc.append("Titulo", titulo.getText());
				doc.append("Autor", autor.getText());
				doc.append("Anyo_nacimientot", Integer.parseInt(anyo_nacimiento.getText()));
				doc.append("Anyo_publicacion", Integer.parseInt(anyo_publicacion.getText()));
				doc.append("Editorial", editorial.getText());
				doc.append("Numero_paginas", Integer.parseInt(numero_paginas.getText()));
				doc.append("Thumbnail", thumbnail.getText());
				coleccion.updateOne(eq("Id", Integer.parseInt(id.getText())), new Document("$set", doc));

				JOptionPane.showMessageDialog(null, "Informació del llibre amb id " + id + "actualitzada amb exit!");
				System.out.println("Información actualizada con exito!");
			} else {
				JOptionPane.showMessageDialog(null, "Opcio cancelada");
			}

		} else {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}
		mongoClient.close();
	}

	
	/**
	 * 
	 * @return devuelve un string con los datos del libro según el id introducido
	 * @throws ParseException
	 */
	
	public String consultarLlibre() throws ParseException {
		String visualizar = "";

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");

		JTextField id = new JTextField();

		Object[] datos = { "Introduixca l'id del llibre que vol consultar: ", id };

		int opcio1 = JOptionPane.showConfirmDialog(null, datos, "Consultar llibre", JOptionPane.YES_NO_OPTION);

		if (opcio1 == JOptionPane.YES_OPTION) {

			MongoCursor<Document> cursor = coleccion.find().iterator();
			Bson query = eq("Id", Integer.parseInt(id.getText()));
			cursor = coleccion.find(query).iterator();
			visualizar += "Datos del libro con id " + id.getText() + "\n";
			// visualizar+="Datos del libro";
			while (cursor.hasNext()) {
				JSONParser parser = new JSONParser();
				JSONObject json;
				json = (JSONObject) parser.parse(cursor.next().toJson());

				if (json.containsKey("Id")) {
					visualizar += "Id: " + Integer.parseInt(json.get("Id").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Titulo")) {
					visualizar += "Titol: " + (String) json.get("Titulo") + "\n";
				}
				if (json.containsKey("Autor")) {
					visualizar += "Autor: " + (String) json.get("Autor") + "\n";
				}
				if (json.containsKey("Anyo_nacimiento")) {
					visualizar += "Any de naixement: " + Integer.parseInt(json.get("Anyo_nacimiento").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Anyo_publicacion")) {
					visualizar += "Any de publicació: " + Integer.parseInt(json.get("Anyo_publicacion").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Editorial")) {
					visualizar += "Editorial: " + (String) json.get("Editorial") + "\n";
				}
				if (json.containsKey("Numero_paginas")) {
					visualizar += "Nombre de págines: " + Integer.parseInt(json.get("Numero_paginas").toString());
					visualizar += "\n";
				}

				System.out.println(visualizar);
			}
		} else if (opcio1 == JOptionPane.NO_OPTION) {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}

		mongoClient.close();
		return visualizar;

	}
	
	
	/**
	 * Elimina la colección books entera 
	 */

	public void eliminarColeccio() {
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");

		int resp = JOptionPane.showConfirmDialog(null, "¿Esta seguro?", "Alerta!", JOptionPane.YES_NO_OPTION);

		if (resp == JOptionPane.YES_OPTION) {
			coleccion.drop();
		} else {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}
		mongoClient.close();
	}

	@SuppressWarnings("deprecation")
	
	/**
	 * 
	 * @return devuelve un string informando del número total de elementos que hay en la colección
	 */
	public String totalElements() {

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");

		int tamanyo = 0;
		tamanyo = (int) coleccion.count();

		String tamanyoTotal = "";
		tamanyoTotal += "El tamanyo total de la colecció es de ";
		tamanyoTotal += String.valueOf(tamanyo) + " elements";

		mongoClient.close();
		return tamanyoTotal;

	}
	
	/**
	 * 
	 * @return Visualiza la información total de los libros que hay en la colección books
	 * @throws ParseException
	 */

	public String visualitzaInfo() throws ParseException {

		String visualitzar = "";
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		while (cursor.hasNext()) {
			// JSONObject obj = new JSONObject(cursor.next().toJson());
			JSONParser parser = new JSONParser();
			JSONObject json;
			json = (JSONObject) parser.parse(cursor.next().toJson());

			System.out.print("ID: " + json.get("Id"));
			System.out.println(" Titulo: " + json.get("Titulo"));
			visualitzar += ("ID: " + json.get("Id"));
			visualitzar += (" Titulo: " + json.get("Titulo"));
			visualitzar += "\n";
		}
		mongoClient.close();

		return visualitzar;

	}
	
	/**
	 * 
	 * @param tipo recibe el tipo de dato a consultar de tipo string
	 * @return devuelve string con la información del dato a consultar
	 * @throws ParseException
	 */

	public String ejecutaConsultaString(String tipo) throws ParseException {

		String visualizar = "";
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		JTextField condicio = new JTextField();
		Object[] datos = { "Introduixca la condicio = a : ", condicio };
		int opcio = JOptionPane.showConfirmDialog(null, datos, "Afegir condicio", JOptionPane.YES_NO_OPTION);

		visualizar += "Libros con " + tipo + " = a :" + condicio.getText() + "\n";

		if (opcio == JOptionPane.YES_OPTION) {
			System.out.println("entra");
			Bson query = eq(tipo, condicio.getText());
			cursor = coleccion.find(query).iterator();
			while (cursor.hasNext()) {
				JSONParser parser = new JSONParser();
				JSONObject json;
				json = (JSONObject) parser.parse(cursor.next().toJson());

				if (json.containsKey("Id")) {
					visualizar += "Id: " + Integer.parseInt(json.get("Id").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Titulo")) {
					visualizar += "Titol: " + (String) json.get("Titulo") + "\n";
				}
				if (json.containsKey("Autor")) {
					visualizar += "Autor: " + (String) json.get("Autor") + "\n";
				}
				if (json.containsKey("Anyo_nacimiento")) {
					visualizar += "Any de naixement: " + Integer.parseInt(json.get("Anyo_nacimiento").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Anyo_publicacion")) {
					visualizar += "Any de publicació: " + Integer.parseInt(json.get("Anyo_publicacion").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Editorial")) {
					visualizar += "Editorial: " + (String) json.get("Editorial") + "\n";
				}
				if (json.containsKey("Numero_paginas")) {
					visualizar += "Nombre de págines: " + Integer.parseInt(json.get("Numero_paginas").toString());
					visualizar += "\n";
				}

				visualizar += "-------------------------------------------";
				visualizar += "\n";

				System.out.println(visualizar);
			}
		} else {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}
		mongoClient.close();

		return visualizar;
	}
	
	/**
	 * 
	 * @param tipo -> recibe el tipo de dato a consultar de tipo int
	 * @return->  devuelve string con la información del dato a consultar
	 * @throws ParseException
	 */
	public String ejecutaConsultaInt(String tipo) throws ParseException {

		String visualizar = "";
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		JTextField condicio = new JTextField();
		Object[] datos = { "Introduixca la condicio = a : ", condicio };
		int opcio = JOptionPane.showConfirmDialog(null, datos, "Afegir condicio", JOptionPane.YES_NO_OPTION);

		visualizar += "Libros con " + tipo + " = a :" + condicio.getText() + "\n";

		if (opcio == JOptionPane.YES_OPTION) {
			System.out.println("entra");
			Bson query = eq(tipo, Integer.parseInt(condicio.getText()));
			int num = Integer.parseInt(condicio.getText());
			System.out.println(num);
			cursor = coleccion.find(query).iterator();
			while (cursor.hasNext()) {
				JSONParser parser = new JSONParser();
				JSONObject json;
				json = (JSONObject) parser.parse(cursor.next().toJson());

				if (json.containsKey("Id")) {
					visualizar += "Id: " + Integer.parseInt(json.get("Id").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Titulo")) {
					visualizar += "Titol: " + (String) json.get("Titulo") + "\n";
				}
				if (json.containsKey("Autor")) {
					visualizar += "Autor: " + (String) json.get("Autor") + "\n";
				}
				if (json.containsKey("Anyo_nacimiento")) {
					visualizar += "Any de naixement: " + Integer.parseInt(json.get("Anyo_nacimiento").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Anyo_publicacion")) {
					visualizar += "Any de publicació: " + Integer.parseInt(json.get("Anyo_publicacion").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Editorial")) {
					visualizar += "Editorial: " + (String) json.get("Editorial") + "\n";
				}
				if (json.containsKey("Numero_paginas")) {
					visualizar += "Nombre de págines: " + Integer.parseInt(json.get("Numero_paginas").toString());
					visualizar += "\n";
				}

				visualizar += "-------------------------------------------";
				visualizar += "\n";

				System.out.println(visualizar);
			}
		} else {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}
		mongoClient.close();

		return visualizar;
	}
	
	/**
	 * 
	 * @param tipo-> recibe el tipo de dato a consultar 
	 * @return devuelve string con la información del dato a consultar
	 * @throws ParseException
	 */

	public String ejecutaConsultaMayor(String tipo) throws ParseException {

		String visualizar = "";
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		JTextField condicio = new JTextField();
		Object[] datos = { "Introduixca la condicio > a : ", condicio };
		int opcio = JOptionPane.showConfirmDialog(null, datos, "Afegir condicio", JOptionPane.YES_NO_OPTION);

		visualizar += "Libros con " + tipo + " > a :" + condicio.getText() + "\n";

		if (opcio == JOptionPane.YES_OPTION) {
			System.out.println("entra");
			Bson query = gte(tipo, Integer.parseInt(condicio.getText()));
			int num = Integer.parseInt(condicio.getText());
			System.out.println(num);
			cursor = coleccion.find(query).iterator();
			while (cursor.hasNext()) {
				JSONParser parser = new JSONParser();
				JSONObject json;
				json = (JSONObject) parser.parse(cursor.next().toJson());

				if (json.containsKey("Id")) {
					visualizar += "Id: " + Integer.parseInt(json.get("Id").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Titulo")) {
					visualizar += "Titol: " + (String) json.get("Titulo") + "\n";
				}
				if (json.containsKey("Autor")) {
					visualizar += "Autor: " + (String) json.get("Autor") + "\n";
				}
				if (json.containsKey("Anyo_nacimiento")) {
					visualizar += "Any de naixement: " + Integer.parseInt(json.get("Anyo_nacimiento").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Anyo_publicacion")) {
					visualizar += "Any de publicació: " + Integer.parseInt(json.get("Anyo_publicacion").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Editorial")) {
					visualizar += "Editorial: " + (String) json.get("Editorial") + "\n";
				}
				if (json.containsKey("Numero_paginas")) {
					visualizar += "Nombre de págines: " + Integer.parseInt(json.get("Numero_paginas").toString());
					visualizar += "\n";
				}

				visualizar += "-------------------------------------------";
				visualizar += "\n";

				System.out.println(visualizar);
			}
		} else {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}
		mongoClient.close();

		return visualizar;
	}
	
	/**
	 * 
	 * @param tipo recibe el tipo de dato a consultar 
	 * @return devuelve string con la información del dato a consultar
	 * @throws ParseException
	 */
	
	public String ejecutaConsultaMenor(String tipo) throws ParseException {

		String visualizar = "";
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		JTextField condicio = new JTextField();
		Object[] datos = { "Introduixca la condicio < a : ", condicio };
		int opcio = JOptionPane.showConfirmDialog(null, datos, "Afegir condicio", JOptionPane.YES_NO_OPTION);

		visualizar += "Libros con " + tipo + " < a :" + condicio.getText() + "\n";

		if (opcio == JOptionPane.YES_OPTION) {
			System.out.println("entra");
			Bson query = lte(tipo, Integer.parseInt(condicio.getText()));
			int num = Integer.parseInt(condicio.getText());
			System.out.println(num);
			cursor = coleccion.find(query).iterator();
			while (cursor.hasNext()) {
				JSONParser parser = new JSONParser();
				JSONObject json;
				json = (JSONObject) parser.parse(cursor.next().toJson());

				if (json.containsKey("Id")) {
					visualizar += "Id: " + Integer.parseInt(json.get("Id").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Titulo")) {
					visualizar += "Titol: " + (String) json.get("Titulo") + "\n";
				}
				if (json.containsKey("Autor")) {
					visualizar += "Autor: " + (String) json.get("Autor") + "\n";
				}
				if (json.containsKey("Anyo_nacimiento")) {
					visualizar += "Any de naixement: " + Integer.parseInt(json.get("Anyo_nacimiento").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Anyo_publicacion")) {
					visualizar += "Any de publicació: " + Integer.parseInt(json.get("Anyo_publicacion").toString());
					visualizar += "\n";
				}
				if (json.containsKey("Editorial")) {
					visualizar += "Editorial: " + (String) json.get("Editorial") + "\n";
				}
				if (json.containsKey("Numero_paginas")) {
					visualizar += "Nombre de págines: " + Integer.parseInt(json.get("Numero_paginas").toString());
					visualizar += "\n";
				}

				visualizar += "-------------------------------------------";
				visualizar += "\n";

				System.out.println(visualizar);
			}
		} else {
			JOptionPane.showMessageDialog(null, "Opcio cancelada");
		}
		mongoClient.close();

		return visualizar;
		
	}
	
	/**
	 * 
	 * @return devuelve string con la información del dato a consultar
	 * @throws ParseException
	 */
	
	public String consultaIgual() throws ParseException {

		String visualizar = "";
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		String[] valores = { "Titol", "Autor", "Any de naixement", "Any de publicacio", "Editorial",
				"Nombre de pagines" };

		String resp = (String) JOptionPane.showInputDialog(null, "Consulta = IGUAL = ",
				"Seleccione un campo a visualizar:  ", +JOptionPane.DEFAULT_OPTION, null, valores, valores[0]);

		if (resp.equals("Titol")) {
			visualizar += ejecutaConsultaString("Titulo");
			System.out.println("ha elegido titulo");
		} else if (resp.equals("Autor")) {
			visualizar += ejecutaConsultaString("Autor");
			System.out.println("ha elegido autor");
		} else if (resp.equals("Editorial")) {
			visualizar += ejecutaConsultaString("Editorial");
			System.out.println("ha elegido editorial");
		} else if (resp.equals("Any de naixement")) {
			visualizar += ejecutaConsultaInt("Anyo_nacimiento");
			System.out.println("ha elegido anyo nacimiento");
		} else if (resp.equals("Any de publicacio")) {
			visualizar += ejecutaConsultaInt("Anyo_publicacion");
			System.out.println("ha elegido Any de publicacio");
		} else if (resp.equals("Nombre de pagines")) {
			visualizar += ejecutaConsultaInt("Numero_paginas");
			System.out.println("ha elegido Nombre de pagines");
		}
		mongoClient.close();

		return visualizar;

	}

	/**
	 * 
	 * @return devuelve string con la información del dato a consultar
	 * @throws ParseException
	 */
	public String consultaMayorQue() throws ParseException {
		String visualizar = "";
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		String[] valores = { "Any de naixement", "Any de publicacio", "Nombre de pagines" };

		String resp = (String) JOptionPane.showInputDialog(null, "Consulta > MAYOR > ",
				"Seleccione un campo a visualizar:  ", +JOptionPane.DEFAULT_OPTION, null, valores, valores[0]);

		if (resp.equals("Any de naixement")) {
			visualizar += ejecutaConsultaMayor("Anyo_nacimiento");
			System.out.println("ha elegido anyo nacimiento");
		} else if (resp.equals("Any de publicacio")) {
			visualizar += ejecutaConsultaMayor("Anyo_publicacion");
			System.out.println("ha elegido Any de publicacio");
		} else if (resp.equals("Nombre de pagines")) {
			visualizar += ejecutaConsultaMayor("Numero_paginas");
			System.out.println("ha elegido Nombre de pagines");
		}
		mongoClient.close();
		return visualizar;
	}
	
	/**
	 * 
	 * @return devuelve string con la información del dato a consultar
	 * @throws ParseException
	 */
	public String consultaMenorQue() throws ParseException {
		String visualizar = "";
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("ADD_ARIADNA");
		MongoCollection<Document> coleccion = database.getCollection("books");
		MongoCursor<Document> cursor = coleccion.find().iterator();

		String[] valores = { "Any de naixement", "Any de publicacio", "Nombre de pagines" };

		String resp = (String) JOptionPane.showInputDialog(null, "Consulta < MENOR < ",
				"Seleccione un campo a visualizar:  ", +JOptionPane.DEFAULT_OPTION, null, valores, valores[0]);

		if (resp.equals("Any de naixement")) {
			visualizar += ejecutaConsultaMenor("Anyo_nacimiento");
			System.out.println("ha elegido anyo nacimiento");
		} else if (resp.equals("Any de publicacio")) {
			visualizar += ejecutaConsultaMenor("Anyo_publicacion");
			System.out.println("ha elegido Any de publicacio");
		} else if (resp.equals("Nombre de pagines")) {
			visualizar += ejecutaConsultaMenor("Numero_paginas");
			System.out.println("ha elegido Nombre de pagines");
		}
		mongoClient.close();

		return visualizar;
	}
}
