package aev03;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Vista extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JLabel lblLibreria;
	private JPanel panel_login;
	private JLabel lblAccsUsuaris;
	private JLabel lblLogin;
	private JLabel lblContra;
	private JButton btnAcces;
	private JLabel lblNewLabel;
	private JPanel panel_funciones;
	private JLabel lblContingut;
	private JScrollPane scrollPane_1;
	private JButton btnTancarConexio;
	private JPanel panel_resum_coleccio;
	private JLabel lbl_resum;
	private JButton btnNomElements;
	private JButton btnVeureLlibres; 
	private JPanel panel_crud;
	private JButton btnCrear;
	private JButton btnMostrar;
	private JButton btnActualitza;
	private JButton btnBorrar;
	private JButton btnEliminaColeccio;
	private JPanel panel_ejecutar_cons;
	private JLabel lblConsulta;
	private JButton btnIgual;
	private JButton btnMajor;
	private JButton btnMenor;
	private JTextArea textAreaVisor;
	
	
	
	
	

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public Vista() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 893, 705);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblLibreria = new JLabel("LLIBRERIA");
		lblLibreria.setBounds(25, 28, 230, 58);
		lblLibreria.setFont(new Font("Dialog", Font.PLAIN, 45));
		contentPane.add(lblLibreria);
		
		panel_login = new JPanel();
		panel_login.setLayout(null);
		panel_login.setBackground(new Color(113, 184, 255));
		panel_login.setBounds(281, 11, 260, 186);
		contentPane.add(panel_login);
		
		lblAccsUsuaris = new JLabel("ACCÉS USUARIS");
		lblAccsUsuaris.setIcon(new ImageIcon(Vista.class.getResource("/aev03/user.png")));
		lblAccsUsuaris.setFont(new Font("Tw Cen MT", Font.PLAIN, 25));
		lblAccsUsuaris.setBounds(19, 11, 231, 60);
		panel_login.add(lblAccsUsuaris);
		
		lblLogin = new JLabel("LOGIN:");
		lblLogin.setFont(new Font("Tw Cen MT", Font.PLAIN, 16));
		lblLogin.setBounds(56, 76, 49, 18);
		panel_login.add(lblLogin);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(130, 76, 86, 20);
		panel_login.add(textField);
		
		lblContra = new JLabel("CONTRASENYA:");
		lblContra.setFont(new Font("Tw Cen MT", Font.PLAIN, 16));
		lblContra.setBounds(14, 100, 107, 18);
		panel_login.add(lblContra);
		
		btnAcces = new JButton("Accedir");
		btnAcces.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnAcces.setBounds(79, 137, 107, 25);
		panel_login.add(btnAcces);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(130, 107, 86, 20);
		panel_login.add(passwordField);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Vista.class.getResource("/aev03/icono_libro.png")));
		lblNewLabel.setBounds(715, 60, 130, 122);
		contentPane.add(lblNewLabel);
		
		panel_funciones = new JPanel();
		panel_funciones.setLayout(null);
		panel_funciones.setBackground(new Color(0, 91, 183));
		panel_funciones.setBounds(25, 208, 836, 444);
		contentPane.add(panel_funciones);
		
		lblContingut = new JLabel("CONTINGUT:");
		lblContingut.setForeground(Color.WHITE);
		lblContingut.setFont(new Font("Tw Cen MT", Font.BOLD, 20));
		lblContingut.setBounds(32, 15, 146, 26);
		panel_funciones.add(lblContingut);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(32, 59, 787, 204);
		panel_funciones.add(scrollPane_1);
		
		textAreaVisor = new JTextArea();
		textAreaVisor.setEditable(false);
		textAreaVisor.setFont(new Font("Monospaced", Font.PLAIN, 20));
		scrollPane_1.setViewportView(textAreaVisor);
		
		btnTancarConexio = new JButton("Tancar connexio");
		btnTancarConexio.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnTancarConexio.setBounds(642, 16, 165, 26);
		panel_funciones.add(btnTancarConexio);
		
		panel_resum_coleccio = new JPanel();
		panel_resum_coleccio.setLayout(null);
		panel_resum_coleccio.setBackground(new Color(113, 184, 255));
		panel_resum_coleccio.setBounds(40, 273, 230, 146);
		panel_funciones.add(panel_resum_coleccio);
		
		lbl_resum = new JLabel("RESÚM COLECCIÓ");
		lbl_resum.setFont(new Font("Tw Cen MT", Font.PLAIN, 16));
		lbl_resum.setBounds(55, 11, 125, 18);
		panel_resum_coleccio.add(lbl_resum);
		
		btnNomElements = new JButton("NOMBRE D'ELEMENTS");
		btnNomElements.setHorizontalAlignment(SwingConstants.LEADING);
		btnNomElements.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnNomElements.setBounds(21, 40, 186, 37);
		panel_resum_coleccio.add(btnNomElements);
		
		btnVeureLlibres = new JButton("VEURE TOTS ELS LLIBRES");
	
		btnVeureLlibres.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnVeureLlibres.setBounds(21, 88, 186, 37);
		panel_resum_coleccio.add(btnVeureLlibres);
		
	    panel_crud = new JPanel();
		panel_crud.setLayout(null);
		panel_crud.setBackground(new Color(113, 184, 255));
		panel_crud.setBounds(312, 267, 230, 166);
		panel_funciones.add(panel_crud);
		
		btnCrear = new JButton("AFEGIR LLIBRE");
		btnCrear.setBounds(38, 21, 150, 23);
		panel_crud.add(btnCrear);
		
		btnMostrar = new JButton("CONSULTAR LLIBRE");
		
		btnMostrar.setBounds(38, 47, 150, 23);
		panel_crud.add(btnMostrar);
		
		btnActualitza = new JButton("ACTUALITZAR INFO.");
		btnActualitza.setBounds(38, 73, 150, 23);
		panel_crud.add(btnActualitza);
		
		btnBorrar = new JButton("ELIMINAR LLIBRE");
		btnBorrar.setBounds(38, 98, 150, 23);
		panel_crud.add(btnBorrar);
		
		btnEliminaColeccio = new JButton("ELIMINAR TOTA LA COLECCIO");
		btnEliminaColeccio.setForeground(new Color(255, 0, 0));
		btnEliminaColeccio.setBounds(23, 132, 182, 23);
		panel_crud.add(btnEliminaColeccio);
		
		panel_ejecutar_cons = new JPanel();
		panel_ejecutar_cons.setLayout(null);
		panel_ejecutar_cons.setBackground(new Color(113, 184, 255));
		panel_ejecutar_cons.setBounds(577, 273, 230, 146);
		panel_funciones.add(panel_ejecutar_cons);
		
		lblConsulta = new JLabel("CONSULTAR:");
		lblConsulta.setFont(new Font("Tw Cen MT", Font.PLAIN, 16));
		lblConsulta.setBounds(67, 11, 99, 18);
		panel_ejecutar_cons.add(lblConsulta);
		
		btnIgual = new JButton("= IGUAL =");
		btnIgual.setBounds(63, 36, 103, 23);
		panel_ejecutar_cons.add(btnIgual);
		
		btnMajor = new JButton("> MAJOR >");
		btnMajor.setBounds(63, 70, 103, 23);
		panel_ejecutar_cons.add(btnMajor);
		
		btnMenor = new JButton("< MENOR <");
		btnMenor.setBounds(63, 104, 103, 23);
		panel_ejecutar_cons.add(btnMenor);
	
		this.setVisible(true);
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public JTextField getTextField() {
		return textField;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public JPanel getPanel_login() {
		return panel_login;
	}

	public JLabel getLblAccsUsuaris() {
		return lblAccsUsuaris;
	}

	public JLabel getLblLogin() {
		return lblLogin;
	}

	public JLabel getLblContra() {
		return lblContra;
	}

	public JButton getBtnAcces() {
		return btnAcces;
	}

	public JLabel getLblNewLabel() {
		return lblNewLabel;
	}

	public JPanel getPanel_funciones() {
		return panel_funciones;
	}

	public JLabel getLblContingut() {
		return lblContingut;
	}

	public JScrollPane getScrollPane_1() {
		return scrollPane_1;
	}

	public JButton getBtnTancarConexio() {
		return btnTancarConexio;
	}

	public JPanel getPanel_resum_coleccio() {
		return panel_resum_coleccio;
	}

	public JLabel getLbl_resum() {
		return lbl_resum;
	}

	public JButton getBtnNomElements() {
		return btnNomElements;
	}

	public JButton getBtnVeureLlibres() {
		return btnVeureLlibres;
	}

	public JPanel getPanel_crud() {
		return panel_crud;
	}

	public JButton getBtnCrear() {
		return btnCrear;
	}

	public JButton getBtnMostrar() {
		return btnMostrar;
	}

	public JButton getBtnActualitza() {
		return btnActualitza;
	}

	public JButton getBtnBorrar() {
		return btnBorrar;
	}

	public JButton getBtnEliminaColeccio() {
		return btnEliminaColeccio;
	}

	public JPanel getPanel_ejecutar_cons() {
		return panel_ejecutar_cons;
	}

	public JLabel getLblConsulta() {
		return lblConsulta;
	}

	public JButton getBtnIgual() {
		return btnIgual;
	}

	public JButton getBtnMajor() {
		return btnMajor;
	}

	public JButton getBtnMenor() {
		return btnMenor;
	}
	
	public JTextArea getTextAreaVisor() {
		return textAreaVisor;
	}
	
}
